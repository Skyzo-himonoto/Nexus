"use client";

import { useState, useEffect } from "react";
import { motion, useScroll, useTransform } from "framer-motion";
import { 
  ArrowRight, 
  Zap, 
  Shield, 
  Globe, 
  Code, 
  Bot,
  TrendingUp,
  CreditCard,
  QrCode,
  Webhook,
  Bell,
  Lock,
  Users,
  ChevronRight,
  Star,
  Rocket,
  Sparkles
} from "lucide-react";
import Link from "next/link";
import { signIn } from "next-auth/react";

export default function LandingPage() {
  const { scrollYProgress } = useScroll();
  const opacity = useTransform(scrollYProgress, [0, 0.5], [1, 0.3]);
  const scale = useTransform(scrollYProgress, [0, 0.5], [1, 0.95]);
  
  const [stats, setStats] = useState({
    transactions: "0",
    merchants: "0",
    volume: "0"
  });

  useEffect(() => {
    const animateValue = (start: number, end: number, duration: number, setter: (val: string) => void, suffix = "") => {
      const increment = (end - start) / (duration / 16);
      let current = start;
      const timer = setInterval(() => {
        current += increment;
        if (current >= end) {
          setter(end.toLocaleString() + suffix);
          clearInterval(timer);
        } else {
          setter(Math.floor(current).toLocaleString() + suffix);
        }
      }, 16);
    };
    
    animateValue(0, 2500000, 2000, (v) => setStats(prev => ({ ...prev, transactions: v })), "+");
    animateValue(0, 10000, 2000, (v) => setStats(prev => ({ ...prev, merchants: v })), "+");
    animateValue(0, 500, 2000, (v) => setStats(prev => ({ ...prev, volume: v })), "B+");
  }, []);

  const features = [
    { icon: <Zap className="w-6 h-6" />, title: "Fast Integration", description: "Get started in minutes with our simple API", gradient: "from-purple-500 to-pink-500", delay: 0 },
    { icon: <Shield className="w-6 h-6" />, title: "Enterprise Security", description: "PCI-DSS compliant with advanced fraud protection", gradient: "from-cyan-500 to-blue-500", delay: 0.1 },
    { icon: <Globe className="w-6 h-6" />, title: "Global Payments", description: "Accept payments in multiple currencies", gradient: "from-emerald-500 to-teal-500", delay: 0.2 },
    { icon: <Code className="w-6 h-6" />, title: "Developer First", description: "Beautiful documentation and SDKs", gradient: "from-orange-500 to-red-500", delay: 0.3 },
    { icon: <Bot className="w-6 h-6" />, title: "Bot Friendly", description: "Native support for WhatsApp, Telegram bots", gradient: "from-purple-500 to-cyan-500", delay: 0.4 },
    { icon: <TrendingUp className="w-6 h-6" />, title: "Real-time Analytics", description: "Live insights and detailed reports", gradient: "from-yellow-500 to-orange-500", delay: 0.5 },
  ];

  const paymentMethods = [
    "QRIS", "BCA VA", "Mandiri VA", "BNI VA", "OVO", "Dana", "GoPay", "ShopeePay", "Alfamart", "Indomaret"
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-gray-900 to-black overflow-hidden">
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-purple-900/20 via-transparent to-transparent" />
        {[...Array(50)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-1 h-1 bg-purple-500/30 rounded-full"
            initial={{ 
              x: Math.random() * window.innerWidth, 
              y: Math.random() * window.innerHeight,
              opacity: Math.random() * 0.5
            }}
            animate={{
              y: [null, -100, -200],
              opacity: [null, 0.2, 0]
            }}
            transition={{
              duration: Math.random() * 5 + 3,
              repeat: Infinity,
              delay: Math.random() * 5
            }}
          />
        ))}
        <motion.div 
          className="absolute top-20 -left-48 w-96 h-96 bg-purple-600 rounded-full mix-blend-multiply filter blur-3xl opacity-30"
          animate={{ x: [0, 100, 0], y: [0, -50, 0] }}
          transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
        />
        <motion.div 
          className="absolute bottom-20 -right-48 w-96 h-96 bg-cyan-600 rounded-full mix-blend-multiply filter blur-3xl opacity-30"
          animate={{ x: [0, -100, 0], y: [0, 50, 0] }}
          transition={{ duration: 25, repeat: Infinity, ease: "linear" }}
        />
      </div>

      <nav className="fixed top-0 w-full z-50 glass border-b border-white/10">
        <div className="container mx-auto px-6 py-4">
          <div className="flex justify-between items-center">
            <motion.div 
              className="flex items-center space-x-2"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5 }}
            >
              <div className="w-10 h-10 bg-gradient-to-r from-purple-600 to-cyan-600 rounded-xl flex items-center justify-center shadow-lg shadow-purple-500/25">
                <span className="text-white font-bold text-xl">N</span>
              </div>
              <div>
                <span className="text-2xl font-bold bg-gradient-to-r from-purple-400 via-cyan-400 to-purple-400 bg-clip-text text-transparent bg-[length:200%_auto] animate-gradient">
                  Nexus Pedia
                </span>
                <p className="text-xs text-gray-400 hidden md:block">Premium Payment Gateway</p>
              </div>
            </motion.div>
            
            <motion.div 
              className="hidden md:flex space-x-8"
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
            >
              {["Features", "Documentation", "Pricing", "API"].map((item) => (
                <a key={item} href={`#${item.toLowerCase()}`} className="text-gray-300 hover:text-white transition group">
                  {item}
                  <span className="block max-w-0 group-hover:max-w-full transition-all duration-300 h-0.5 bg-gradient-to-r from-purple-500 to-cyan-500"></span>
                </a>
              ))}
            </motion.div>
            
            <motion.div 
              className="flex space-x-4"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5 }}
            >
              <button 
                onClick={() => signIn("google")}
                className="px-4 py-2 hover:bg-white/10 rounded-lg transition text-white"
              >
                Sign In
              </button>
              <Link href="/auth/register">
                <button className="px-6 py-2 bg-gradient-to-r from-purple-600 to-cyan-600 rounded-lg hover:shadow-lg hover:shadow-purple-500/25 transition transform hover:scale-105">
                  Get Started
                  <ArrowRight className="inline ml-2 w-4 h-4" />
                </button>
              </Link>
            </motion.div>
          </div>
        </div>
      </nav>

      <section className="relative pt-32 pb-20 overflow-hidden">
        <div className="container mx-auto px-6 text-center relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <div className="inline-flex items-center px-3 py-1 rounded-full bg-purple-500/10 border border-purple-500/20 mb-6 backdrop-blur-sm">
              <Sparkles className="w-4 h-4 text-purple-400 mr-2" />
              <span className="text-purple-400 text-sm">✨ Nexus payment gateway</span>
            </div>
            
            <h1 className="text-5xl md:text-7xl lg:text-8xl font-bold mb-6">
              <span className="bg-gradient-to-r from-purple-400 via-cyan-400 to-purple-400 bg-clip-text text-transparent bg-[length:200%_auto] animate-gradient">
                Payment Gateway
              </span>
              <br />
              <span className="text-white">for Modern Developers</span>
            </h1>
            
            <p className="text-lg md:text-xl text-gray-400 max-w-2xl mx-auto mb-10">
              Build, scale, and manage payments with Nexus Pedia's developer-friendly API. 
              Accept payments from 20+ methods with just a few lines of code.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <motion.button 
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => signIn("google")}
                className="px-8 py-3 bg-gradient-to-r from-purple-600 to-cyan-600 rounded-lg text-lg font-semibold shadow-lg shadow-purple-500/25"
              >
                Start Building Free
                <ArrowRight className="inline ml-2 w-5 h-5" />
              </motion.button>
              <motion.button 
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="px-8 py-3 border border-purple-500 rounded-lg text-lg font-semibold hover:bg-purple-500/10 transition"
              >
                View Documentation
              </motion.button>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.3 }}
            className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-3xl mx-auto mt-20"
          >
            <div className="glass-card rounded-2xl p-6 text-center group hover:scale-105 transition">
              <div className="text-3xl font-bold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">{stats.transactions}</div>
              <div className="text-gray-400 mt-2">Transactions Processed</div>
            </div>
            <div className="glass-card rounded-2xl p-6 text-center group hover:scale-105 transition">
              <div className="text-3xl font-bold bg-gradient-to-r from-cyan-400 to-blue-400 bg-clip-text text-transparent">{stats.merchants}</div>
              <div className="text-gray-400 mt-2">Active Merchants</div>
            </div>
            <div className="glass-card rounded-2xl p-6 text-center group hover:scale-105 transition">
              <div className="text-3xl font-bold bg-gradient-to-r from-emerald-400 to-teal-400 bg-clip-text text-transparent">{stats.volume}</div>
              <div className="text-gray-400 mt-2">Transaction Volume</div>
            </div>
          </motion.div>
        </div>
      </section>

      <section id="features" className="py-20">
        <div className="container mx-auto px-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-5xl font-bold mb-4">Everything You Need</h2>
            <p className="text-gray-400 text-lg">Powerful features to help you grow your business</p>
          </motion.div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((feature, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: feature.delay }}
                viewport={{ once: true }}
                whileHover={{ y: -10 }}
                className="group"
              >
                <div className="glass-card rounded-2xl p-6 h-full">
                  <div className={`w-14 h-14 bg-gradient-to-r ${feature.gradient} rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition`}>
                    <div className="text-white">{feature.icon}</div>
                  </div>
                  <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
                  <p className="text-gray-400">{feature.description}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20">
        <div className="container mx-auto px-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-4xl md:text-5xl font-bold mb-4">Supported Payment Methods</h2>
            <p className="text-gray-400 text-lg">20+ payment methods available for your business</p>
          </motion.div>
          
          <motion.div 
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="flex flex-wrap justify-center gap-3"
          >
            {paymentMethods.map((method, i) => (
              <motion.div
                key={method}
                initial={{ opacity: 0, scale: 0.8 }}
                whileInView={{ opacity: 1, scale: 1 }}
                transition={{ delay: i * 0.05 }}
                viewport={{ once: true }}
                whileHover={{ scale: 1.05, y: -2 }}
                className="glass px-4 py-2 rounded-lg text-sm font-medium hover:border-purple-500/50 transition"
              >
                {method}
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>
      
      <section className="py-20">
        <div className="container mx-auto px-6">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
            className="glass-card rounded-3xl p-8 md:p-12"
          >
            <div className="grid md:grid-cols-2 gap-12 items-center">
              <div>
                <div className="inline-flex items-center px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/20 mb-4">
                  <Code className="w-4 h-4 text-cyan-400 mr-2" />
                  <span className="text-cyan-400 text-sm">Developer Friendly</span>
                </div>
                <h2 className="text-3xl md:text-4xl font-bold mb-4">Simple & Powerful API</h2>
                <p className="text-gray-300 mb-6">
                  Integrate payments in minutes with our straightforward API. 
                  Create transactions, handle webhooks, and manage refunds with ease.
                </p>
                <div className="space-y-3">
                  {["Type-safe SDKs for all languages", "Real-time webhook events", "Comprehensive documentation"].map((item, i) => (
                    <motion.div 
                      key={i}
                      initial={{ opacity: 0, x: -20 }}
                      whileInView={{ opacity: 1, x: 0 }}
                      transition={{ delay: i * 0.1 }}
                      className="flex items-center gap-3"
                    >
                      <div className="w-5 h-5 rounded-full bg-green-500/20 flex items-center justify-center">
                        <div className="w-1.5 h-1.5 bg-green-500 rounded-full" />
                      </div>
                      <span className="text-gray-300">{item}</span>
                    </motion.div>
                  ))}
                </div>
              </div>
              <motion.div 
                initial={{ opacity: 0, scale: 0.95 }}
                whileInView={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.6, delay: 0.2 }}
                className="bg-black/50 rounded-xl p-4 border border-purple-500/20"
              >
                <pre className="text-sm text-cyan-400 overflow-x-auto">
                  <code>{`// Create payment with one line
const { data } = await nexus.payment.create({
  amount: 50000,
  method: 'QRIS',
  customer: {
    name: 'John Doe',
    email: 'john@example.com'
  }
});

// dapatin payment URL
console.log(data.payment_url);
// https://pay.nexuspedia.com/TXN123456

// Handle webhook
app.post('/webhook', (req, res) => {
  const event = req.body;
  if (event.type === 'payment.success') {
    // Fulfill order
  }
});`}</code>
                </pre>
              </motion.div>
            </div>
          </motion.div>
        </div>
      </section>
      <section className="py-20">
        <div className="container mx-auto px-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-4xl md:text-5xl font-bold mb-4">Bot Integration Ready</h2>
            <p className="text-gray-400 text-lg">Accept payments directly from WhatsApp, Telegram, and Discord</p>
          </motion.div>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-3xl mx-auto">
            {[
              { name: "WhatsApp", icon: "💬", description: "WhatsApp Bot API", gradient: "from-green-500 to-emerald-500" },
              { name: "Telegram", icon: "📱", description: "Telegram Bot API", gradient: "from-blue-500 to-cyan-500" },
              { name: "Discord", icon: "🎮", description: "Discord Bot API", gradient: "from-indigo-500 to-purple-500" },
              { name: "Custom", icon: "🔧", description: "Custom Integration", gradient: "from-orange-500 to-red-500" }
            ].map((bot, i) => (
              <motion.div
                key={bot.name}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                viewport={{ once: true }}
                whileHover={{ y: -5 }}
                className="glass-card rounded-xl p-6 text-center"
              >
                <div className={`text-5xl mb-3 bg-gradient-to-r ${bot.gradient} bg-clip-text text-transparent`}>
                  {bot.icon}
                </div>
                <h3 className="font-semibold">{bot.name}</h3>
                <p className="text-xs text-gray-400 mt-1">{bot.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20">
        <div className="container mx-auto px-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-4xl md:text-5xl font-bold mb-4">Frequently Asked Questions</h2>
            <p className="text-gray-400 text-lg">Got questions? We've got answers</p>
          </motion.div>
          
          <div className="grid md:grid-cols-2 gap-6 max-w-4xl mx-auto">
            {[
              { q: "How long does it take to integrate?", a: "Most merchants integrate within 15 minutes using our simple API and documentation." },
              { q: "What payment methods are supported?", a: "We support 20+ methods including QRIS, Virtual Accounts, E-Wallets, and Bank Transfers." },
              { q: "Is there a holding period for funds?", a: "Yes, funds are held for 24 hours for security before being released to your balance." },
              { q: "How do I get support?", a: "Contact our 24/7 support team via Telegram, email, or live chat." }
            ].map((faq, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                viewport={{ once: true }}
                className="glass-card rounded-xl p-6"
              >
                <h3 className="font-semibold mb-2 flex items-center gap-2">
                  <ChevronRight className="w-4 h-4 text-purple-400" />
                  {faq.q}
                </h3>
                <p className="text-gray-400 text-sm">{faq.a}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20">
        <div className="container mx-auto px-6">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
            className="relative overflow-hidden rounded-3xl p-12 text-center"
          >
            <div className="absolute inset-0 bg-gradient-to-r from-purple-600 to-cyan-600 opacity-90" />
            <div className="absolute inset-0 bg-[url('data:image/svg+xml,%3Csvg width="60" height="60" viewBox="0 0 60 60" xmlns="http://www.w3.org/2000/svg"%3E%3Cg fill="none" fill-rule="evenodd"%3E%3Cg fill="%23ffffff" fill-opacity="0.05"%3E%3Cpath d="M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z"/%3E%3C/g%3E%3C/g%3E%3C/svg%3E')] opacity-10" />
            <div className="relative z-10">
              <h2 className="text-3xl md:text-4xl font-bold mb-4 text-white">Ready to start accepting payments?</h2>
              <p className="text-purple-100 mb-8 text-lg">Join thousands of developers using Nexus Pedia</p>
              <motion.button 
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => signIn("google")}
                className="px-8 py-3 bg-white text-purple-600 rounded-lg font-semibold hover:bg-gray-100 transition shadow-lg"
              >
                Create Free Account
                <Rocket className="inline ml-2 w-5 h-5" />
              </motion.button>
            </div>
          </motion.div>
        </div>
      </section>

      <footer className="border-t border-white/10 py-12">
        <div className="container mx-auto px-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <div className="w-8 h-8 bg-gradient-to-r from-purple-600 to-cyan-600 rounded-lg flex items-center justify-center">
                  <span className="text-white font-bold">N</span>
                </div>
                <span className="text-lg font-bold gradient-text">Nexus Pedia</span>
              </div>
              <p className="text-gray-400 text-sm">Modern Payment Infrastructure for Developers</p>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Product</h3>
              <ul className="space-y-2 text-gray-400 text-sm">
                <li><a href="#" className="hover:text-purple-400 transition">Features</a></li>
                <li><a href="#" className="hover:text-purple-400 transition">Pricing</a></li>
                <li><a href="#" className="hover:text-purple-400 transition">Documentation</a></li>
                <li><a href="#" className="hover:text-purple-400 transition">API Reference</a></li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Company</h3>
              <ul className="space-y-2 text-gray-400 text-sm">
                <li><a href="#" className="hover:text-purple-400 transition">About</a></li>
                <li><a href="#" className="hover:text-purple-400 transition">Blog</a></li>
                <li><a href="#" className="hover:text-purple-400 transition">Careers</a></li>
                <li><a href="#" className="hover:text-purple-400 transition">Contact</a></li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Legal</h3>
              <ul className="space-y-2 text-gray-400 text-sm">
                <li><a href="#" className="hover:text-purple-400 transition">Terms</a></li>
                <li><a href="#" className="hover:text-purple-400 transition">Privacy</a></li>
                <li><a href="#" className="hover:text-purple-400 transition">Security</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-white/10 mt-8 pt-8 text-center text-gray-400 text-sm">
            <p>&copy; 2024 Nexus Pedia. All rights reserved.</p>
          </div>
        </div>
      </footer>

      <style jsx>{`
        @keyframes gradient {
          0% { background-position: 0% 50%; }
          50% { background-position: 100% 50%; }
          100% { background-position: 0% 50%; }
        }
        .animate-gradient {
          background-size: 200% auto;
          animation: gradient 3s linear infinite;
        }
        .glass-card {
          background: rgba(255, 255, 255, 0.03);
          backdrop-filter: blur(10px);
          border: 1px solid rgba(255, 255, 255, 0.08);
          transition: all 0.3s ease;
        }
        .glass-card:hover {
          border-color: rgba(168, 85, 247, 0.3);
          box-shadow: 0 0 30px rgba(168, 85, 247, 0.1);
        }
        .glass {
          background: rgba(255, 255, 255, 0.05);
          backdrop-filter: blur(10px);
          border: 1px solid rgba(255, 255, 255, 0.1);
        }
      `}</style>
    </div>
  );
}