import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { prisma } from "@/lib/prisma";
import { rateLimit } from "@/lib/rate-limit";
import { z } from "zod";
import { authOptions } from "@/lib/auth";
import { DuitkuProvider } from "@/lib/providers/duitku";
import { MidtransProvider } from "@/lib/providers/midtrans";

const paymentSchema = z.object({
  amount: z.number().min(1000, "Minimal Rp 5.000"),
  paymentMethod: z.enum(["QRIS", "BCA_VA", "MANDIRI_VA", "OVO", "DANA", "GOPAY"]),
  customerName: z.string().min(1),
  customerEmail: z.string().email(),
  customerPhone: z.string().optional(),
  note: z.string().optional(),
  redirectUrl: z.string().url().optional(),
  callbackUrl: z.string().url().optional(),
});

export async function POST(req: NextRequest) {
  try {
    const ip = req.headers.get("x-forwarded-for") || "anonymous";
    const { success } = await rateLimit.limit(ip);
    if (!success) {
      return NextResponse.json({ error: "Rate limit exceeded" }, { status: 429 });
    }

    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await req.json();
    const validated = paymentSchema.parse(body);

    const transactionId = `TXN${Date.now()}${Math.random().toString(36).substring(2, 10)}`.toUpperCase();
    const expiredAt = new Date();
    expiredAt.setHours(expiredAt.getHours() + 24);

    const transaction = await prisma.transaction.create({
      data: {
        transactionId,
        userId: session.user.id,
        amount: validated.amount,
        totalAmount: validated.amount,
        status: "PENDING",
        type: "PAYMENT",
        paymentMethod: validated.paymentMethod,
        customerInfo: {
          name: validated.customerName,
          email: validated.customerEmail,
          phone: validated.customerPhone,
        },
        note: validated.note,
        expiredAt,
        callbackUrl: validated.callbackUrl,
        redirectUrl: validated.redirectUrl,
      },
    });

    let provider;
    let paymentResponse;

    if (validated.paymentMethod === "QRIS") {
      provider = new DuitkuProvider({
        merchantCode: process.env.DUITKU_MERCHANT_CODE!,
        apiKey: process.env.DUITKU_API_KEY!,
        sandbox: process.env.DUITKU_SANDBOX_MODE === "true",
      });
      
      paymentResponse = await provider.createTransaction({
        amount: validated.amount,
        transactionId: transaction.transactionId,
        customerName: validated.customerName,
        customerEmail: validated.customerEmail,
        paymentMethod: "QRIS",
        returnUrl: validated.redirectUrl,
        callbackUrl: `${process.env.NEXTAUTH_URL}/api/webhook/duitku`,
      });
    } else {
      provider = new MidtransProvider({
        serverKey: process.env.MIDTRANS_SERVER_KEY!,
        clientKey: process.env.MIDTRANS_CLIENT_KEY!,
        sandbox: process.env.MIDTRANS_SANDBOX_MODE === "true",
      });
      
      paymentResponse = await provider.createTransaction({
        amount: validated.amount,
        transactionId: transaction.transactionId,
        customerName: validated.customerName,
        customerEmail: validated.customerEmail,
        paymentMethod: validated.paymentMethod,
      });
    }

    const invoice = await prisma.invoice.create({
      data: {
        invoiceCode: `INV${Date.now()}${Math.random().toString(36).substring(2, 8)}`.toUpperCase(),
        transactionId: transaction.id,
        userId: session.user.id,
        amount: validated.amount,
        paymentUrl: paymentResponse.paymentUrl,
        qrCode: paymentResponse.qrCode,
        expiredAt,
      },
    });

    await prisma.log.create({
      data: {
        userId: session.user.id,
        action: "CREATE_PAYMENT",
        ipAddress: ip,
        userAgent: req.headers.get("user-agent") || undefined,
        metadata: {
          transactionId: transaction.transactionId,
          amount: validated.amount,
          paymentMethod: validated.paymentMethod,
        },
      },
    });

    return NextResponse.json({
      success: true,
      data: {
        transactionId: transaction.transactionId,
        invoiceCode: invoice.invoiceCode,
        amount: validated.amount,
        paymentUrl: paymentResponse.paymentUrl,
        qrCode: paymentResponse.qrCode,
        expiredAt: expiredAt.toISOString(),
        status: "PENDING",
      },
    });
  } catch (error) {
    console.error("Payment creation error:", error);
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to create payment" },
      { status: 500 }
    );
  }
}