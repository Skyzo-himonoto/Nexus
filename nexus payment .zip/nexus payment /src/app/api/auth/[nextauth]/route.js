import NextAuth from "next-auth";
import GoogleProvider from "next-auth/providers/google";
import { PrismaAdapter } from "@auth/prisma-adapter";
import { prisma } from "@/lib/prisma";
import { sendOTPEmail } from "@/lib/email";

const handler = NextAuth({
  adapter: PrismaAdapter(prisma),
  providers: [
    GoogleProvider({
      clientId: process.env.GOOGLE_CLIENT_ID!,
      clientSecret: process.env.GOOGLE_CLIENT_SECRET!,
    }),
  ],
  callbacks: {
    async signIn({ user, account, profile }) {
      if (account?.provider === "google") {
        const existingBalance = await prisma.balance.findUnique({
          where: { userId: user.id }
        });
        
        if (!existingBalance) {
          await prisma.balance.create({
            data: {
              userId: user.id,
              holdingBalance: 0,
              availableBalance: 0,
              withdrawBalance: 0,
            }
          });
        }
      }
      return true;
    },
    async session({ session, token }) {
      if (session.user) {
        session.user.id = token.sub!;
        const userData = await prisma.user.findUnique({
          where: { id: token.sub! },
          include: { balances: true }
        });
        session.user.balance = userData?.balances[0];
      }
      return session;
    }
  },
  pages: {
    signIn: "/auth/signin",
    verifyRequest: "/auth/verify",
  },
  session: {
    strategy: "jwt",
  },
  secret: process.env.NEXTAUTH_SECRET,
});

export { handler as GET, handler as POST };