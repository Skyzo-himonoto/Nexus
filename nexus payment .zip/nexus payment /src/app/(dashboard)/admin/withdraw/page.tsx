"use client";

import { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { CheckCircle, XCircle, Download, Eye } from "lucide-react";

export default function AdminWithdraws() {
  const [withdraws, setWithdraws] = useState([]);
  const [stats, setStats] = useState({
    pending: 0,
    processing: 0,
    completed: 0,
    totalFeeIncome: 0,
  });

  useEffect(() => {
    fetchWithdraws();
  }, []);

  const fetchWithdraws = async () => {
    const res = await fetch("/api/admin/withdraws");
    const data = await res.json();
    setWithdraws(data.withdraws);
    setStats(data.stats);
  };

  const handleApprove = async (id: string) => {
    await fetch("/api/admin/withdraws/approve", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ withdrawId: id }),
    });
    fetchWithdraws();
  };

  const handleReject = async (id: string) => {
    await fetch("/api/admin/withdraws/reject", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ withdrawId: id }),
    });
    fetchWithdraws();
  };

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Withdraw Management</h1>
        <p className="text-gray-400 mt-2">Manage user withdrawal requests</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-gradient-to-br from-yellow-500/10 to-yellow-600/10 border-yellow-500/20 p-4">
          <p className="text-yellow-400 text-sm">Pending</p>
          <p className="text-2xl font-bold">{stats.pending}</p>
        </Card>
        <Card className="bg-gradient-to-br from-blue-500/10 to-blue-600/10 border-blue-500/20 p-4">
          <p className="text-blue-400 text-sm">Processing</p>
          <p className="text-2xl font-bold">{stats.processing}</p>
        </Card>
        <Card className="bg-gradient-to-br from-green-500/10 to-green-600/10 border-green-500/20 p-4">
          <p className="text-green-400 text-sm">Completed</p>
          <p className="text-2xl font-bold">{stats.completed}</p>
        </Card>
        <Card className="bg-gradient-to-br from-purple-500/10 to-purple-600/10 border-purple-500/20 p-4">
          <p className="text-purple-400 text-sm">Fee Income</p>
          <p className="text-2xl font-bold">Rp {stats.totalFeeIncome.toLocaleString()}</p>
        </Card>
      </div>

      <Card className="bg-white/5 border-white/10">
        <div className="p-6">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-xl font-semibold">Withdraw Requests</h2>
            <Button variant="outline" size="sm">
              <Download className="w-4 h-4 mr-2" />
              Export
            </Button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-white/10">
                  <th className="text-left p-3">User</th>
                  <th className="text-left p-3">Amount</th>
                  <th className="text-left p-3">Fee</th>
                  <th className="text-left p-3">Net Amount</th>
                  <th className="text-left p-3">Bank</th>
                  <th className="text-left p-3">Status</th>
                  <th className="text-left p-3">Date</th>
                  <th className="text-left p-3">Actions</th>
                </tr>
              </thead>
              <tbody>
                {withdraws.map((withdraw: any) => (
                  <tr key={withdraw.id} className="border-b border-white/5">
                    <td className="p-3">
                      <div>
                        <p className="font-medium">{withdraw.user.name}</p>
                        <p className="text-sm text-gray-400">{withdraw.user.email}</p>
                      </div>
                    </td>
                    <td className="p-3 font-medium">Rp {withdraw.amount.toLocaleString()}</td>
                    <td className="p-3 text-red-400">Rp {withdraw.fee.toLocaleString()}</td>
                    <td className="p-3 text-green-400">Rp {withdraw.netAmount.toLocaleString()}</td>
                    <td className="p-3">
                      <div>
                        <p>{withdraw.bankName}</p>
                        <p className="text-sm text-gray-400">{withdraw.accountNumber}</p>
                      </div>
                    </td>
                    <td className="p-3">
                      <Badge className={
                        withdraw.status === "PENDING" ? "bg-yellow-500" :
                        withdraw.status === "PROCESSING" ? "bg-blue-500" :
                        withdraw.status === "SUCCESS" ? "bg-green-500" : "bg-red-500"
                      }>
                        {withdraw.status}
                      </Badge>
                    </td>
                    <td className="p-3 text-sm text-gray-400">
                      {new Date(withdraw.createdAt).toLocaleDateString()}
                    </td>
                    <td className="p-3">
                      {withdraw.status === "PENDING" && (
                        <div className="flex gap-2">
                          <Button size="sm" onClick={() => handleApprove(withdraw.id)}>
                            <CheckCircle className="w-4 h-4 mr-1" />
                            Approve
                          </Button>
                          <Button size="sm" variant="destructive" onClick={() => handleReject(withdraw.id)}>
                            <XCircle className="w-4 h-4 mr-1" />
                            Reject
                          </Button>
                        </div>
                      )}
                      {withdraw.status === "PROCESSING" && (
                        <Button size="sm" variant="outline">
                          <Eye className="w-4 h-4 mr-1" />
                          Track
                        </Button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </Card>
    </div>
  );
}