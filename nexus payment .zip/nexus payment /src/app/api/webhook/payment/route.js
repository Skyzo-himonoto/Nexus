import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { addHours } from "date-fns";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    
    const signature = req.headers.get("x-signature");
    const generatedSignature = generateSignature(body);
    
    if (signature !== generatedSignature) {
      return NextResponse.json({ error: "Invalid signature" }, { status: 401 });
    }

    const {
      merchantOrderId,
      paymentAmount,
      statusCode,
      statusMessage,
      paymentMethod,
      transactionId: providerTransactionId,
      paidAt,
    } = body;

    const isSuccess = statusCode === "00" || statusCode === "0000";
    
    if (isSuccess) {
      const transaction = await prisma.transaction.findUnique({
        where: { transactionId: merchantOrderId },
      });

      if (!transaction) {
        return NextResponse.json({ error: "Transaction not found" }, { status: 404 });
      }

      const holdingUntil = addHours(new Date(), 24);

      await prisma.$transaction(async (tx) => {
        await tx.transaction.update({
          where: { id: transaction.id },
          data: {
            status: "HOLDING",
            paidAt: new Date(paidAt),
            holdingUntil,
            paymentMethod,
            providerTransactionId,
          },
        });
        
        await tx.settlement.create({
          data: {
            transactionId: transaction.id,
            userId: transaction.userId,
            amount: paymentAmount,
            status: "HOLDING",
            holdingUntil,
          },
        });

        await tx.balance.update({
          where: { userId: transaction.userId },
          data: {
            holdingBalance: { increment: paymentAmount },
          },
        });

        await tx.invoice.update({
          where: { transactionId: transaction.id },
          data: { status: "PAID" },
        });

        await tx.notification.create({
          data: {
            userId: transaction.userId,
            title: "Payment Received",
            message: `Payment of Rp ${paymentAmount.toLocaleString()} received via ${paymentMethod}. Funds on hold for 24 hours.`,
            type: "PAYMENT_SUCCESS",
            data: {
              transactionId: merchantOrderId,
              amount: paymentAmount,
              holdingUntil: holdingUntil.toISOString(),
            },
          },
        });
      });

      if (transaction.callbackUrl) {
        await fetch(transaction.callbackUrl, {
          method: "POST",
          headers: { 
            "Content-Type": "application/json",
            "X-Webhook-Signature": generateWebhookSignature(transaction)
          },
          body: JSON.stringify({
            event: "payment.success",
            transactionId: merchantOrderId,
            amount: paymentAmount,
            status: "HOLDING",
            holdingUntil: holdingUntil.toISOString(),
            paymentMethod,
          }),
        });
      }
    }

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Webhook error:", error);
    return NextResponse.json({ error: "Internal error" }, { status: 500 });
  }
}

function generateSignature(body: any) {
  const crypto = require('crypto');
  const hash = crypto.createHash('md5');
  const signatureString = body.merchantCode + body.merchantOrderId + body.paymentAmount + process.env.DUITKU_API_KEY;
  return hash.update(signatureString).digest('hex');
}

function generateWebhookSignature(transaction: any) {
  const crypto = require('crypto');
  return crypto.createHash('sha256').update(transaction.id + process.env.WEBHOOK_SECRET).digest('hex');
}