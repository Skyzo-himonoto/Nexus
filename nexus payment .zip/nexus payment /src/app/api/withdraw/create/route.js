import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { prisma } from "@/lib/prisma";
import { rateLimit } from "@/lib/rate-limit";
import { z } from "zod";

const withdrawSchema = z.object({
  amount: z.number().min(10000, "Minimal withdraw Rp 10.000"),
  bankName: z.string().min(1, "Bank name required"),
  accountNumber: z.string().min(5, "Valid account number required"),
  accountName: z.string().min(3, "Account name required"),
});

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession();
    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const identifier = `withdraw:${session.user.id}`;
    const { success } = await rateLimit.limit(identifier);
    if (!success) {
      return NextResponse.json(
        { error: "Too many withdraw requests. Please wait 5 minutes." },
        { status: 429 }
      );
    }

    const body = await req.json();
    const validated = withdrawSchema.parse(body);
    const balance = await prisma.$transaction(async (tx) => {
      const bal = await tx.balance.findUnique({
        where: { userId: session.user.id },
      });
      
      if (!bal) throw new Error("Balance not found");
      if (bal.availableBalance < validated.amount) {
        throw new Error("Insufficient balance");
      }
      
      return bal;
    });

    const WITHDRAW_FEE = 3000; // fee Rp 3,000
    const netAmount = validated.amount - WITHDRAW_FEE;

    if (netAmount < 10000) {
      return NextResponse.json(
        { error: `After fee (Rp ${WITHDRAW_FEE}), minimum received is Rp 10,000` },
        { status: 400 }
      );
    }

    const withdraw = await prisma.$transaction(async (tx) => {
      const wd = await tx.withdraw.create({
        data: {
          userId: session.user.id,
          amount: validated.amount,
          fee: WITHDRAW_FEE,
          netAmount,
          bankName: validated.bankName,
          accountNumber: validated.accountNumber,
          accountName: validated.accountName,
          status: "PENDING",
        },
      });

      await tx.balance.update({
        where: { userId: session.user.id },
        data: {
          availableBalance: { decrement: validated.amount },
          withdrawBalance: { increment: validated.amount },
          totalWithdrawn: { increment: validated.amount },
        },
      });

      await tx.transaction.create({
        data: {
          transactionId: `WDR${Date.now()}${Math.random().toString(36).substring(7)}`.toUpperCase(),
          userId: session.user.id,
          amount: validated.amount,
          fee: WITHDRAW_FEE,
          totalAmount: netAmount,
          status: "PENDING",
          type: "WITHDRAW",
          paymentMethod: "BANK_TRANSFER",
          customerInfo: {
            bank: validated.bankName,
            accountNumber: validated.accountNumber,
            accountName: validated.accountName,
          },
        },
      });

      await tx.notification.create({
        data: {
          userId: session.user.id,
          title: "Withdraw Request Submitted",
          message: `Your withdraw request of Rp ${validated.amount.toLocaleString()} has been submitted. Admin will process within 24 hours.`,
          type: "WITHDRAW_SUCCESS",
          data: {
            withdrawId: wd.id,
            amount: validated.amount,
            netAmount,
          },
        },
      });

      await tx.log.create({
        data: {
          userId: session.user.id,
          action: "CREATE_WITHDRAW",
          ipAddress: req.headers.get("x-forwarded-for") || undefined,
          userAgent: req.headers.get("user-agent") || undefined,
          metadata: {
            amount: validated.amount,
            bank: validated.bankName,
            netAmount,
          },
        },
      });

      return wd;
    });

    return NextResponse.json({
      success: true,
      data: {
        withdrawId: withdraw.id,
        amount: validated.amount,
        fee: WITHDRAW_FEE,
        netAmount,
        status: "PENDING",
        estimatedProcessing: "24 hours",
        message: `Withdraw request created. You will receive Rp ${netAmount.toLocaleString()} after admin approval.`,
      },
    });
  } catch (error) {
    console.error("Withdraw error:", error);
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to create withdraw" },
      { status: 500 }
    );
  }
}