"use client";

import { useState, useEffect } from "react";
import { useSession } from "next-auth/react";
import { motion } from "framer-motion";
import {
  LineChart,
  Line,
  AreaChart,
  Area,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend
} from "recharts";
import {
  TrendingUp,
  TrendingDown,
  Wallet,
  CreditCard,
  Clock,
  CheckCircle,
  ArrowUpRight,
  ArrowDownRight,
  RefreshCw
} from "lucide-react";

const transactionData = [
  { name: "Mon", amount: 12500000, success: 98 },
  { name: "Tue", amount: 18900000, success: 95 },
  { name: "Wed", amount: 15200000, success: 97 },
  { name: "Thu", amount: 22100000, success: 99 },
  { name: "Fri", amount: 19800000, success: 96 },
  { name: "Sat", amount: 17500000, success: 94 },
  { name: "Sun", amount: 14200000, success: 97 },
];

const paymentMethodsData = [
  { name: "QRIS", value: 45, color: "#a855f7" },
  { name: "Virtual Account", value: 30, color: "#06b6d4" },
  { name: "E-Wallet", value: 25, color: "#ec4899" },
];

const recentTransactions = [
  { id: "TXN20241201001", amount: 150000, method: "QRIS", status: "success", date: "2024-12-01 14:30", customer: "Ahmad R." },
  { id: "TXN20241201002", amount: 75000, method: "BCA VA", status: "holding", date: "2024-12-01 13:15", customer: "Budi S." },
  { id: "TXN20241130001", amount: 200000, method: "OVO", status: "success", date: "2024-11-30 10:45", customer: "Citra D." },
  { id: "TXN20241129001", amount: 500000, method: "Mandiri VA", status: "pending", date: "2024-11-29 09:20", customer: "Dewi K." },
];

export default function DashboardPage() {
  const { data: session } = useSession();
  const [stats, setStats] = useState({
    totalRevenue: 84750000,
    totalTransactions: 342,
    successRate: 98.5,
    pendingSettlement: 12500000,
    withdrawable: 2500000,
    holding: 12500000,
  });
  const [isLoading, setIsLoading] = useState(false);

  const statsCards = [
    { 
      title: "Total Revenue", 
      value: `Rp ${stats.totalRevenue.toLocaleString()}`, 
      change: "+12.5%", 
      trend: "up",
      icon: <Wallet className="w-5 h-5" />,
      gradient: "from-purple-500 to-pink-500"
    },
    { 
      title: "Total Transactions", 
      value: stats.totalTransactions, 
      change: "+8.3%", 
      trend: "up",
      icon: <CreditCard className="w-5 h-5" />,
      gradient: "from-cyan-500 to-blue-500"
    },
    { 
      title: "Success Rate", 
      value: `${stats.successRate}%`, 
      change: "+2.1%", 
      trend: "up",
      icon: <CheckCircle className="w-5 h-5" />,
      gradient: "from-emerald-500 to-teal-500"
    },
    { 
      title: "Pending Settlement", 
      value: `Rp ${stats.pendingSettlement.toLocaleString()}`, 
      change: "-5.2%", 
      trend: "down",
      icon: <Clock className="w-5 h-5" />,
      gradient: "from-orange-500 to-red-500"
    },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl md:text-3xl font-bold">Welcome back, {session?.user?.name?.split(" ")[0] || "User"}!</h1>
        <p className="text-gray-400 mt-1">Here's your payment overview for today</p>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {statsCards.map((stat, index) => (
          <motion.div
            key={stat.title}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            whileHover={{ y: -5 }}
            className="glass-card rounded-xl p-5"
          >
            <div className="flex justify-between items-start">
              <div>
                <p className="text-sm text-gray-400">{stat.title}</p>
                <p className="text-2xl font-bold mt-1">{stat.value}</p>
                <div className={`flex items-center gap-1 mt-2 text-sm ${stat.trend === "up" ? "text-green-400" : "text-red-400"}`}>
                  {stat.trend === "up" ? <ArrowUpRight className="w-4 h-4" /> : <ArrowDownRight className="w-4 h-4" />}
                  <span>{stat.change}</span>
                </div>
              </div>
              <div className={`w-10 h-10 bg-gradient-to-r ${stat.gradient} rounded-xl flex items-center justify-center`}>
                <div className="text-white">{stat.icon}</div>
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.4 }}
          className="relative overflow-hidden rounded-xl p-6"
          style={{
            background: "linear-gradient(135deg, rgba(168,85,247,0.15), rgba(6,182,212,0.05))",
            border: "1px solid rgba(168,85,247,0.2)"
          }}
        >
          <div className="absolute top-0 right-0 w-32 h-32 bg-purple-500/10 rounded-full blur-2xl" />
          <div className="relative z-10">
            <p className="text-sm text-gray-400">Available Balance</p>
            <p className="text-3xl font-bold mt-1">Rp {stats.withdrawable.toLocaleString()}</p>
            <p className="text-xs text-green-400 mt-2 flex items-center gap-1">
              <RefreshCw className="w-3 h-3" />
              Ready for withdrawal
            </p>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.5 }}
          className="relative overflow-hidden rounded-xl p-6"
          style={{
            background: "linear-gradient(135deg, rgba(234,179,8,0.15), rgba(249,115,22,0.05))",
            border: "1px solid rgba(234,179,8,0.2)"
          }}
        >
          <div className="absolute top-0 right-0 w-32 h-32 bg-yellow-500/10 rounded-full blur-2xl" />
          <div className="relative z-10">
            <p className="text-sm text-gray-400">Holding Balance</p>
            <p className="text-3xl font-bold mt-1">Rp {stats.holding.toLocaleString()}</p>
            <p className="text-xs text-yellow-400 mt-2 flex items-center gap-1">
              <Clock className="w-3 h-3" />
              Released in 24 hours
            </p>
          </div>
        </motion.div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="glass-card rounded-xl p-5"
        >
          <h3 className="font-semibold mb-4">Transaction Overview</h3>
          <ResponsiveContainer width="100%" height={300}>
            <AreaChart data={transactionData}>
              <defs>
                <linearGradient id="colorAmount" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#a855f7" stopOpacity={0.3}/>
                  <stop offset="95%" stopColor="#a855f7" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#333" />
              <XAxis dataKey="name" stroke="#666" />
              <YAxis stroke="#666" tickFormatter={(value) => `Rp ${(value/1000000).toFixed(0)}M`} />
              <Tooltip 
                contentStyle={{ backgroundColor: "#1a1a2e", border: "1px solid #333", borderRadius: "8px" }}
                formatter={(value) => [`Rp ${value.toLocaleString()}`, "Amount"]}
              />
              <Area type="monotone" dataKey="amount" stroke="#a855f7" fillOpacity={1} fill="url(#colorAmount)" />
            </AreaChart>
          </ResponsiveContainer>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.7 }}
          className="glass-card rounded-xl p-5"
        >
          <h3 className="font-semibold mb-4">Payment Methods Distribution</h3>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={paymentMethodsData}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={100}
                paddingAngle={5}
                dataKey="value"
                label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                labelLine={false}
              >
                {paymentMethodsData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip 
                contentStyle={{ backgroundColor: "#1a1a2e", border: "1px solid #333", borderRadius: "8px" }}
                formatter={(value) => [`${value}%`, "Percentage"]}
              />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        </motion.div>
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.8 }}
        className="glass-card rounded-xl overflow-hidden"
      >
        <div className="p-5 border-b border-white/10">
          <h3 className="font-semibold">Recent Transactions</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-white/5">
              <tr className="text-left text-sm">
                <th className="p-4">Transaction ID</th>
                <th className="p-4">Customer</th>
                <th className="p-4">Amount</th>
                <th className="p-4">Method</th>
                <th className="p-4">Status</th>
                <th className="p-4">Date</th>
              </tr>
            </thead>
            <tbody>
              {recentTransactions.map((tx, index) => (
                <motion.tr
                  key={tx.id}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.9 + index * 0.05 }}
                  className="border-b border-white/5 hover:bg-white/5 transition"
                >
                  <td className="p-4 font-mono text-sm">{tx.id}</td>
                  <td className="p-4 text-sm">{tx.customer}</td>
                  <td className="p-4 font-semibold">Rp {tx.amount.toLocaleString()}</td>
                  <td className="p-4 text-sm">{tx.method}</td>
                  <td className="p-4">
                    <span className={`text-xs px-2 py-1 rounded-full ${
                      tx.status === "success" ? "bg-green-500/20 text-green-400" :
                      tx.status === "holding" ? "bg-yellow-500/20 text-yellow-400" :
                      "bg-blue-500/20 text-blue-400"
                    }`}>
                      {tx.status}
                    </span>
                  </td>
                  <td className="p-4 text-sm text-gray-400">{tx.date}</td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>
      </motion.div>
    </div>
  );
}