git add .
git commit -m "deploy nexus payment"
git push origin main

# main vercel , add evironments
DATABASE_URL 
NEXTAUTH_SECRET 
GOOGLE_CLIENT_ID 
GOOGLE_CLIENT_SECRET 
DUITKU_MERCHANT_CODE 
DUITKU_API_KEY 
MIDTRANS_SERVER_KEY 
UPSTASH_REDIS_URL 
OWNER_TELEGRAM_USERNAME 

# create payment termux
POST /api/payment/create
Authorization: Bearer YOUR_API_KEY
Content-Type: application/json

{
  "amount": 50000,
  "paymentMethod": "QRIS",
  "customerName": "John Doe",
  "customerEmail": "john@example.com"
}
