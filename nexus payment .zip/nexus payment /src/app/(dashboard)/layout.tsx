"use client";

import { useState, useEffect } from "react";
import { useSession, signOut } from "next-auth/react";
import { useRouter } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";
import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  LayoutDashboard,
  CreditCard,
  Key,
  Wallet,
  Webhook,
  Settings,
  LogOut,
  Menu,
  X,
  Bell,
  User,
  ChevronDown,
  Home,
  History,
  TrendingUp,
  Shield,
  Zap,
  Database,
  Users,
  DollarSign,
  Activity,
  FileText,
  HelpCircle,
  MessageCircle
} from "lucide-react";

const menuItems = [
  { name: "Dashboard", icon: <LayoutDashboard className="w-5 h-5" />, href: "/dashboard", category: "main" },
  { name: "Transactions", icon: <CreditCard className="w-5 h-5" />, href: "/transactions", category: "main" },
  { name: "Create Payment", icon: <Zap className="w-5 h-5" />, href: "/create-payment", category: "main" },
  { name: "API Keys", icon: <Key className="w-5 h-5" />, href: "/api-keys", category: "developer" },
  { name: "Webhooks", icon: <Webhook className="w-5 h-5" />, href: "/webhook", category: "developer" },
  { name: "Withdraw", icon: <Wallet className="w-5 h-5" />, href: "/withdraw", category: "finance" },
  { name: "Analytics", icon: <TrendingUp className="w-5 h-5" />, href: "/analytics", category: "analytics" },
  { name: "Settings", icon: <Settings className="w-5 h-5" />, href: "/settings", category: "settings" },
];

const adminItems = [
  { name: "Withdraw Requests", icon: <Users className="w-5 h-5" />, href: "/admin/withdraws", category: "admin" },
  { name: "User Management", icon: <Database className="w-5 h-5" />, href: "/admin/users", category: "admin" },
  { name: "System Logs", icon: <Activity className="w-5 h-5" />, href: "/admin/logs", category: "admin" },
];

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const { data: session, status } = useSession();
  const router = useRouter();
  const pathname = usePathname();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [userMenuOpen, setUserMenuOpen] = useState(false);
  const [notifications, setNotifications] = useState([]);
  const [showNotifications, setShowNotifications] = useState(false);

  useEffect(() => {
    if (status === "unauthenticated") {
      router.push("/");
    }
  }, [status, router]);

  if (status === "loading") {
    return (
      <div className="min-h-screen bg-gradient-to-br from-black via-gray-900 to-black flex items-center justify-center">
        <div className="relative">
          <div className="w-16 h-16 border-4 border-purple-500/20 border-t-purple-500 rounded-full animate-spin" />
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-8 h-8 bg-gradient-to-r from-purple-600 to-cyan-600 rounded-full animate-pulse" />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-gray-900 to-black">
      <AnimatePresence>
        {sidebarOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setSidebarOpen(false)}
            className="fixed inset-0 bg-black/50 z-40 md:hidden"
          />
        )}
      </AnimatePresence>

      <motion.aside
        initial={{ x: -280 }}
        animate={{ x: sidebarOpen ? 0 : -280 }}
        transition={{ type: "spring", damping: 20 }}
        className="fixed top-0 left-0 w-72 h-full bg-gray-900/95 backdrop-blur-xl border-r border-white/10 z-50 flex flex-col"
      >
        {/* Logo */}
        <div className="p-6 border-b border-white/10">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-to-r from-purple-600 to-cyan-600 rounded-xl flex items-center justify-center shadow-lg shadow-purple-500/25">
              <span className="text-white font-bold text-xl">N</span>
            </div>
            <div>
              <span className="text-xl font-bold bg-gradient-to-r from-purple-400 to-cyan-400 bg-clip-text text-transparent">Nexus Pedia</span>
              <p className="text-xs text-gray-500">Premium Gateway</p>
            </div>
          </div>
        </div>

        <div className="p-4 border-b border-white/10">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-500 to-cyan-500 flex items-center justify-center">
              <span className="text-white font-semibold">
                {session?.user?.name?.[0]?.toUpperCase() || "U"}
              </span>
            </div>
            <div className="flex-1">
              <p className="font-semibold text-sm">{session?.user?.name}</p>
              <p className="text-xs text-gray-400">{session?.user?.email}</p>
            </div>
            <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
          </div>
        </div>
        <nav className="flex-1 overflow-y-auto p-4 space-y-6">
          <div>
            <p className="text-xs text-gray-500 uppercase tracking-wider mb-3 px-3">Main Menu</p>
            <div className="space-y-1">
              {menuItems.filter(i => i.category === "main").map((item) => (
                <Link key={item.href} href={item.href}>
                  <motion.div
                    whileHover={{ x: 5 }}
                    className={`flex items-center space-x-3 px-3 py-2 rounded-lg transition ${
                      pathname === item.href
                        ? "bg-gradient-to-r from-purple-600/20 to-cyan-600/20 border-l-3 border-purple-500 text-white"
                        : "text-gray-400 hover:text-white hover:bg-white/5"
                    }`}
                  >
                    {item.icon}
                    <span className="text-sm">{item.name}</span>
                  </motion.div>
                </Link>
              ))}
            </div>
          </div>

          <div>
            <p className="text-xs text-gray-500 uppercase tracking-wider mb-3 px-3">Developer Tools</p>
            <div className="space-y-1">
              {menuItems.filter(i => i.category === "developer").map((item) => (
                <Link key={item.href} href={item.href}>
                  <motion.div
                    whileHover={{ x: 5 }}
                    className={`flex items-center space-x-3 px-3 py-2 rounded-lg transition ${
                      pathname === item.href
                        ? "bg-gradient-to-r from-purple-600/20 to-cyan-600/20 border-l-3 border-purple-500 text-white"
                        : "text-gray-400 hover:text-white hover:bg-white/5"
                    }`}
                  >
                    {item.icon}
                    <span className="text-sm">{item.name}</span>
                  </motion.div>
                </Link>
              ))}
            </div>
          </div>

          <div>
            <p className="text-xs text-gray-500 uppercase tracking-wider mb-3 px-3">Finance</p>
            <div className="space-y-1">
              {menuItems.filter(i => i.category === "finance").map((item) => (
                <Link key={item.href} href={item.href}>
                  <motion.div
                    whileHover={{ x: 5 }}
                    className={`flex items-center space-x-3 px-3 py-2 rounded-lg transition ${
                      pathname === item.href
                        ? "bg-gradient-to-r from-purple-600/20 to-cyan-600/20 border-l-3 border-purple-500 text-white"
                        : "text-gray-400 hover:text-white hover:bg-white/5"
                    }`}
                  >
                    {item.icon}
                    <span className="text-sm">{item.name}</span>
                  </motion.div>
                </Link>
              ))}
            </div>
          </div>

          {session?.user?.role === "admin" && (
            <div>
              <p className="text-xs text-gray-500 uppercase tracking-wider mb-3 px-3">Admin</p>
              <div className="space-y-1">
                {adminItems.map((item) => (
                  <Link key={item.href} href={item.href}>
                    <motion.div
                      whileHover={{ x: 5 }}
                      className={`flex items-center space-x-3 px-3 py-2 rounded-lg transition ${
                        pathname === item.href
                          ? "bg-gradient-to-r from-purple-600/20 to-cyan-600/20 border-l-3 border-purple-500 text-white"
                          : "text-gray-400 hover:text-white hover:bg-white/5"
                      }`}
                    >
                      {item.icon}
                      <span className="text-sm">{item.name}</span>
                    </motion.div>
                  </Link>
                ))}
              </div>
            </div>
          )}
        </nav>

        <div className="p-4 border-t border-white/10">
          <button
            onClick={() => signOut()}
            className="flex items-center space-x-3 px-3 py-2 w-full rounded-lg text-red-400 hover:bg-red-500/10 transition"
          >
            <LogOut className="w-5 h-5" />
            <span className="text-sm">Logout</span>
          </button>
        </div>
      </motion.aside>

      <div className={`transition-all duration-300 ${sidebarOpen ? "md:ml-72" : "ml-0"}`}>
        <header className="sticky top-0 z-30 glass border-b border-white/10">
          <div className="flex items-center justify-between px-6 py-4">
            <button
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className="p-2 rounded-lg hover:bg-white/10 transition"
            >
              <Menu className="w-5 h-5" />
            </button>

            <div className="flex items-center space-x-4">
              <div className="relative">
                <button
                  onClick={() => setShowNotifications(!showNotifications)}
                  className="p-2 rounded-lg hover:bg-white/10 transition relative"
                >
                  <Bell className="w-5 h-5" />
                  {notifications.length > 0 && (
                    <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full animate-pulse" />
                  )}
                </button>
                
                <AnimatePresence>
                  {showNotifications && (
                    <motion.div
                      initial={{ opacity: 0, y: -10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -10 }}
                      className="absolute right-0 mt-2 w-80 glass rounded-xl border border-white/10 shadow-xl z-50"
                    >
                      <div className="p-3 border-b border-white/10">
                        <h3 className="font-semibold">Notifications</h3>
                      </div>
                      <div className="max-h-96 overflow-y-auto">
                        <div className="p-4 text-center text-gray-400 text-sm">
                          No new notifications
                        </div>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              <div className="relative">
                <button
                  onClick={() => setUserMenuOpen(!userMenuOpen)}
                  className="flex items-center space-x-2 p-2 rounded-lg hover:bg-white/10 transition"
                >
                  <div className="w-8 h-8 rounded-full bg-gradient-to-br from-purple-500 to-cyan-500 flex items-center justify-center">
                    <span className="text-white text-sm font-semibold">
                      {session?.user?.name?.[0]?.toUpperCase() || "U"}
                    </span>
                  </div>
                  <ChevronDown className="w-4 h-4" />
                </button>

                <AnimatePresence>
                  {userMenuOpen && (
                    <motion.div
                      initial={{ opacity: 0, y: -10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -10 }}
                      className="absolute right-0 mt-2 w-48 glass rounded-xl border border-white/10 shadow-xl z-50"
                    >
                      <div className="p-2">
                        <Link href="/profile">
                          <div className="flex items-center space-x-2 px-3 py-2 rounded-lg hover:bg-white/10 transition">
                            <User className="w-4 h-4" />
                            <span className="text-sm">Profile</span>
                          </div>
                        </Link>
                        <Link href="/settings">
                          <div className="flex items-center space-x-2 px-3 py-2 rounded-lg hover:bg-white/10 transition">
                            <Settings className="w-4 h-4" />
                            <span className="text-sm">Settings</span>
                          </div>
                        </Link>
                        <Link href="/help">
                          <div className="flex items-center space-x-2 px-3 py-2 rounded-lg hover:bg-white/10 transition">
                            <HelpCircle className="w-4 h-4" />
                            <span className="text-sm">Help Center</span>
                          </div>
                        </Link>
                        <div className="border-t border-white/10 my-1" />
                        <button
                          onClick={() => signOut()}
                          className="flex items-center space-x-2 px-3 py-2 rounded-lg hover:bg-red-500/10 transition w-full text-red-400"
                        >
                          <LogOut className="w-4 h-4" />
                          <span className="text-sm">Logout</span>
                        </button>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </div>
          </div>
        </header>

        <main className="p-6">
          {children}
        </main>
      </div>

      <motion.a
        href="https://t.me/nexuspedia_support"
        target="_blank"
        rel="noopener noreferrer"
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ delay: 1, type: "spring" }}
        whileHover={{ scale: 1.1 }}
        className="fixed bottom-6 right-6 z-50"
      >
        <div className="relative">
          <div className="absolute inset-0 bg-gradient-to-r from-purple-600 to-cyan-600 rounded-full blur-lg opacity-50 animate-pulse" />
          <div className="relative w-14 h-14 bg-gradient-to-r from-purple-600 to-cyan-600 rounded-full flex items-center justify-center shadow-lg">
            <MessageCircle className="w-6 h-6 text-white" />
          </div>
        </div>
        <span className="absolute bottom-full right-0 mb-2 px-2 py-1 bg-gray-800 text-xs rounded whitespace-nowrap opacity-0 group-hover:opacity-100 transition">
          Hubungi Admin (Telegram)
        </span>
      </motion.a>
    </div>
  );
}