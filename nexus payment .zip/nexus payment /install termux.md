# npm install

cp .env.example .env.local
# Edit .env.local with credentials

set ap databae
# npx prisma db push
# npx prisma generate

# npm run dev
